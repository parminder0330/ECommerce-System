Everything works as per requirements except for bonus question. All exceptions are handled. products map is created using the products.txt file provided. stats are provided using same map as well.


Exceptions work correctly in eclipse where I compiled it but while testing on cmd it gave errors of exception classes being inaccessible even though they're out of the main class. Please compile in eclipse and everthing should work smoothly.